package newerplayer;

import battlecode.common.*;

public class Politician extends Unit {
    static boolean attack = false;
    static MapLocation attackLoc;
    static final int DISTANCE_TO_EDGE = 3;

    public Politician(RobotController rc) {
        super(rc);
    }

    public MapLocation slandererEdge = null;
    public Direction slandererWallDir = null;
    public Direction roam = Direction.CENTER;
    public int flagMessage = 0;
    static int distanceToEC = 4;
    static int stuckCount = 0;
    static boolean onPosition = false;

    public void run() throws GameActionException {
        super.run();

        if (distanceToEC > 10) {
            distanceToEC = 10;
        }

        if (!rc.isReady()) {
            return;
        }

        //Converted Politician. Doesn't have message because it doesn't know the enlightenment center id.
        if (enlightenmentCenterSpawnedFromMessage == null) {
            //look around for nearby allies to see if they have the enemy EC location set
            targetEnemyECLoc = scanForEnemyEC();
        }

        getEnlightenmentCenterLoc(myTeam);

        //if sense enemy muckraker, ATTACK!
        attack();

        roam2();
    }

    void roam2() throws GameActionException {
        MapLocation[] mapLocationsNearEC = new MapLocation[]{enlightenmentCenterSpawnedFromLoc.translate(-3, 0),
                enlightenmentCenterSpawnedFromLoc.translate(3, 0),
                enlightenmentCenterSpawnedFromLoc.translate(0, 3),
                enlightenmentCenterSpawnedFromLoc.translate(0, -3),
                enlightenmentCenterSpawnedFromLoc.translate(3, 3),
                enlightenmentCenterSpawnedFromLoc.translate(-3, 3),
                enlightenmentCenterSpawnedFromLoc.translate(3, -3),
                enlightenmentCenterSpawnedFromLoc.translate(-3, -3)};
        RobotInfo[] nearbyAllies = rc.senseNearbyRobots(-1, myTeam);
        MapLocation spotsNearestToEC = null;

        for (MapLocation loc : mapLocationsNearEC) {
            if (rc.canSenseLocation(loc) && !rc.isLocationOccupied(loc)) {
                spotsNearestToEC = loc;
            }
            if (myCurrentLoc.equals(loc)) {
                onPosition = true;
                break;
            }
        }

        if (onPosition) {
            notifyNearestSpot(nearbyAllies);
            return;
        }

        if (spotsNearestToEC != null) {
            nav.bugTwo(spotsNearestToEC);
        } else {
            MapLocation whereToGo = getNearestSpotToGoTo(nearbyAllies);
            if (whereToGo != null) {
                nav.bugTwo(whereToGo);
            }
            //Can't use myCurrentLoc because we just moved
            if (rc.getLocation().equals(whereToGo)) {
                onPosition = true;
            }
        }
    }

    public MapLocation scanForEnemyEC() throws GameActionException {
        RobotInfo[] friendlyBots = rc.senseNearbyRobots(-1, myTeam);
        int flag = 0;
        Message msg = null;

        if (friendlyBots != null) {
            for (int i = 0; i < friendlyBots.length; i++) {
                if (rc.canGetFlag(friendlyBots[i].getID())) {
                    flag = rc.getFlag(friendlyBots[i].getID());
                    if (flag != 0) {
                        msg = comms.decodeFlag(flag);
                        if (msg.id == Constants.FOUND_ENEMY_EC) {
                            return msg.location;
                        }
                    }
                }
            }
        }
        return null;
    }

    MapLocation getNearestSpotToGoTo(RobotInfo[] nearbyAllies) throws GameActionException {
        MapLocation nearestLoc = null;
        int distance = 1000;

        //Get the nearest spot of the outer to go to relayed back from other Politicians
        for (RobotInfo ally : nearbyAllies) {
            if (ally.type.equals(RobotType.POLITICIAN) && rc.canGetFlag(ally.ID)) {
                Message decodedMessage = comms.decodeFlag(rc.getFlag(ally.ID));
                if (decodedMessage != null && decodedMessage.id == Constants.OPEN_SPOT
                        && decodedMessage.location.distanceSquaredTo(myCurrentLoc) < distance) {
                    nearestLoc = decodedMessage.location;
                    distance = decodedMessage.location.distanceSquaredTo(myCurrentLoc);
                }
            }
        }

        return nearestLoc;
    }

    void notifyNearestSpot(RobotInfo[] nearbyAllies) throws GameActionException {
        MapLocation[] mapLocations = new MapLocation[]{
                myCurrentLoc.translate(-3, 0),
                myCurrentLoc.translate(3, 0),
                myCurrentLoc.translate(0, 3),
                myCurrentLoc.translate(0, -3),
                myCurrentLoc.translate(3, 3),
                myCurrentLoc.translate(-3, 3),
                myCurrentLoc.translate(3, -3),
                myCurrentLoc.translate(-3, -3)};
        MapLocation notOccupied = null;
        int closestDistanceFromMe = 1000;
        int closestDistanceFromEC = 1000;
        MapLocation flaggedOpenPosition = null;

        //Get the closest outer wall position relayed back from other Politicians
        for (RobotInfo ally : nearbyAllies) {
            if (ally.type.equals(RobotType.POLITICIAN) && rc.canGetFlag(ally.ID)) {
                Message decodedMessage = comms.decodeFlag(rc.getFlag(ally.ID));
                if (decodedMessage != null && decodedMessage.id == Constants.OPEN_SPOT
                        && decodedMessage.location.distanceSquaredTo(enlightenmentCenterSpawnedFromLoc) < closestDistanceFromEC) {
                    flaggedOpenPosition = decodedMessage.location;
                    closestDistanceFromEC = decodedMessage.location.distanceSquaredTo(enlightenmentCenterSpawnedFromLoc);
                }
            }
        }

        //Check there are open spots nearby myself
        for (MapLocation loc : mapLocations) {
            if (rc.canSenseLocation(loc) && !rc.isLocationOccupied(loc)) {
                int distanceToLoc = myCurrentLoc.distanceSquaredTo(loc);
                if (distanceToLoc < closestDistanceFromMe) {
                    closestDistanceFromMe = distanceToLoc;
                    boolean noNearbyPoli = true;
                    RobotInfo[] nearPotentialLoc = rc.senseNearbyRobots(loc, 5, myTeam);

                    //To not connect with other EC lattice - Check if the spot has Politicians that are established nearby
                    for (RobotInfo near : nearPotentialLoc) {
                        if (near.type == RobotType.POLITICIAN && rc.canGetFlag(near.ID)) {
                            Message decodedMessage = comms.decodeFlag(rc.getFlag(near.ID));
                            if (decodedMessage != null && decodedMessage.id == Constants.OPEN_SPOT) {
                                noNearbyPoli = false;
                            }
                        }
                    }
                    if (noNearbyPoli) notOccupied = loc;
                }
            }
        }

        //Priorities flagging nearby vacant spots over relaying other spot
        if (notOccupied != null) {
            comms.setFlag(Constants.OPEN_SPOT, notOccupied);
        } else if (flaggedOpenPosition != null) {
            comms.setFlag(Constants.OPEN_SPOT, flaggedOpenPosition);
        }
    }

}
